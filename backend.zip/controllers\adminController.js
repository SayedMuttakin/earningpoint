const User = require('../models/User');
const Article = require('../models/Article');
const Transaction = require('../models/Transaction');
const Referral = require('../models/Referral');
const SupportTicket = require('../models/SupportTicket');
const Verification = require('../models/Verification');
const PremiumOrder = require('../models/PremiumOrder');
const GlobalSetting = require('../models/GlobalSetting');
const CartProduct = require('../models/CartProduct');
const ChatSession = require('../models/ChatSession');
const WeeklyMission = require('../models/WeeklyMission');
const Notification = require('../models/Notification');
const AdminNotification = require('../models/AdminNotification');
const jwt = require('jsonwebtoken');
const { createNotification } = require('./notificationController');
const { activateReferralBonus } = require('./referralController');

// ─── Admin Login ──────────────────────────────────────────────────────────────
exports.adminLogin = async (req, res) => {
  const { email, password } = req.body;
  const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@zenivio.com';
  const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'Admin@12345';

  if (email !== ADMIN_EMAIL || password !== ADMIN_PASSWORD) {
    return res.status(401).json({ message: 'Invalid admin credentials' });
  }

  const token = jwt.sign(
    { email, role: 'admin' },
    process.env.JWT_SECRET || 'fallback_secret',
    { expiresIn: '7d' }
  );
  res.json({ token, email, role: 'admin' });
};

// ─── Dashboard Stats ─────────────────────────────────────────────────────────
exports.getDashboardStats = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalBalanceAgg = await User.aggregate([{ $group: { _id: null, total: { $sum: '$balance' } } }]);
    const totalTransactions = await Transaction.countDocuments();
    const pendingWithdrawals = await Transaction.countDocuments({ type: 'withdrawal', status: 'pending' });
    const openTickets = await SupportTicket.countDocuments({ status: { $in: ['open', 'in_progress'] } });
    const totalReferrals = await Referral.countDocuments();
    const pendingPremiumOrders = await PremiumOrder.countDocuments({ status: 'pending' });
    const bannedUsers = await User.countDocuments({ isBanned: true });
    const premiumUsers = await User.countDocuments({ isPremium: true });

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayUsers = await User.countDocuments({ createdAt: { $gte: today } });

    const revenueAgg = await Transaction.aggregate([
      { $match: { status: 'completed' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);

    // Last 7 days chart
    const last7Days = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      date.setHours(0, 0, 0, 0);
      const nextDate = new Date(date);
      nextDate.setDate(nextDate.getDate() + 1);

      const users = await User.countDocuments({ createdAt: { $gte: date, $lt: nextDate } });
      const txns = await Transaction.countDocuments({ createdAt: { $gte: date, $lt: nextDate } });
      last7Days.push({
        date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        users,
        transactions: txns,
      });
    }

    const recentUsers = await User.find()
      .sort({ createdAt: -1 })
      .limit(5)
      .select('name phoneOrEmail balance coins isBanned isPremium createdAt');

    const recentTransactions = await Transaction.find()
      .sort({ createdAt: -1 })
      .limit(5)
      .populate('userId', 'name phoneOrEmail');

    res.json({
      totalUsers,
      totalBalance: totalBalanceAgg[0]?.total || 0,
      totalTransactions,
      pendingWithdrawals,
      openTickets,
      totalReferrals,
      pendingPremiumOrders,
      bannedUsers,
      premiumUsers,
      todayUsers,
      revenue: revenueAgg[0]?.total || 0,
      last7Days,
      recentUsers,
      recentTransactions,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: error.message });
  }
};

// ─── Users ────────────────────────────────────────────────────────────────────
exports.getUsers = async (req, res) => {
  try {
    const { search = '', page = 1, limit = 15, filter } = req.query;
    const query = {};

    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { phoneOrEmail: { $regex: search, $options: 'i' } },
        { referralCode: { $regex: search, $options: 'i' } },
      ];
    }
    if (filter === 'banned') query.isBanned = true;
    if (filter === 'premium') query.isPremium = true;
    if (filter === 'verified') {
      query.$or = [
        { isEmailVerified: true },
        { verificationBadge: { $in: ['blue', 'golden'] } }
      ];
    }

    const total = await User.countDocuments(query);
    const users = await User.find(query)
      .select('-password')
      .sort({ createdAt: -1 })
      .skip((Number(page) - 1) * Number(limit))
      .limit(Number(limit));

    res.json({ users, total, page: Number(page), pages: Math.ceil(total / Number(limit)) });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    if (!user) return res.status(404).json({ message: 'User not found' });

    const transactions = await Transaction.find({ userId: req.params.id }).sort({ createdAt: -1 }).limit(10);
    const referrals = await Referral.find({ referrerId: req.params.id })
      .populate('referredUserId', 'name phoneOrEmail')
      .limit(10);
    const verification = await Verification.findOne({ userId: req.params.id });
    const premiumOrders = await PremiumOrder.find({ userId: req.params.id }).sort({ createdAt: -1 }).limit(5);

    res.json({ user, transactions, referrals, verification, premiumOrders });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.updateUser = async (req, res) => {
  try {
    const { balance, coins, points, isBanned, isPremium, premiumExpiry, name, note, verificationBadge } = req.body;
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    const oldBalance = user.balance;
    const oldBadge = user.verificationBadge;
    if (balance !== undefined) user.balance = Number(balance);
    if (points !== undefined) user.points = Number(points);
    if (coins !== undefined) user.points = Number(coins);
    if (isBanned !== undefined) user.isBanned = isBanned;
    if (isPremium !== undefined) user.isPremium = isPremium;
    if (premiumExpiry !== undefined) user.premiumExpiry = premiumExpiry;
    if (name !== undefined) user.name = name;
    if (verificationBadge !== undefined) {
      user.verificationBadge = verificationBadge;
      if (verificationBadge === 'blue' || verificationBadge === 'golden') {
        user.isEmailVerified = true;
      } else if (verificationBadge === 'none') {
        user.isEmailVerified = false;
      }
    }

    await user.save();

    if (verificationBadge !== undefined && verificationBadge !== oldBadge) {
      let title = '';
      let msg = '';
      if (verificationBadge === 'blue') {
        title = 'Verified Public Figure';
        msg = 'This account authentically represents a recognized public figure and has been verified by Zenivio.';
      } else if (verificationBadge === 'golden') {
        title = 'Verified Individual';
        msg = 'This account belongs to a real person whose identity has been verified by Zenivio.';
      } else if (verificationBadge === 'none') {
        title = 'Verification Status Updated';
        msg = 'Your verification badge has been removed by the administrator.';
      }
      createNotification(user._id, title, msg, 'badge');
    }

    if (balance !== undefined && Number(balance) !== oldBalance) {
      const diff = Number(balance) - oldBalance;
      await Transaction.create({
        userId: user._id,
        type: 'earning',
        amount: Math.abs(diff),
        description: note || `Admin balance adjustment (${diff > 0 ? '+' : ''}${diff}৳)`,
        status: 'completed',
      });

      // Notify user about balance adjustment
      createNotification(
        user._id,
        `Balance Updated! 💰`,
        `Your account balance has been updated to ${balance}৳.`,
        'system'
      );
    }

    const updatedUser = await User.findById(req.params.id).select('-password');
    res.json({ message: 'User updated successfully', user: updatedUser });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


exports.deleteUser = async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Transactions ─────────────────────────────────────────────────────────────
exports.getTransactions = async (req, res) => {
  try {
    const { type, status, page = 1, limit = 15 } = req.query;
    const query = {};
    if (type) query.type = type;
    if (status) query.status = status;

    const total = await Transaction.countDocuments(query);
    const transactions = await Transaction.find(query)
      .populate('userId', 'name phoneOrEmail')
      .sort({ createdAt: -1 })
      .skip((Number(page) - 1) * Number(limit))
      .limit(Number(limit));

    res.json({ transactions, total, page: Number(page), pages: Math.ceil(total / Number(limit)) });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getAllWithdrawals = async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const query = { type: 'withdrawal' };
    
    const total = await Transaction.countDocuments(query);
    const withdrawals = await Transaction.find(query)
      .populate('userId', 'name phoneOrEmail')
      .sort({ createdAt: -1 })
      .skip((Number(page) - 1) * Number(limit))
      .limit(Number(limit));
    
    const formatted = withdrawals.map(w => ({
      id: w._id,
      userId: w.userId._id,
      name: w.userId?.name || 'User',
      phone: w.description?.replace(/Withdrawal via .* to /, '') || '',
      amount: w.amount,
      method: w.description?.replace(/Withdrawal via /, '').replace(/ to .*/, '') || 'Unknown',
      date: w.createdAt.toISOString().split('T')[0],
      status: w.status
    }));
    
    res.json({ withdrawals: formatted, total, page: Number(page), pages: Math.ceil(total / Number(limit)) });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.updateTransaction = async (req, res) => {
  try {
    const { status } = req.body;
    const transaction = await Transaction.findById(req.params.id).populate('userId', 'name phoneOrEmail');
    if (!transaction) return res.status(404).json({ message: 'Transaction not found' });

    const oldStatus = transaction.status;
    transaction.status = status;
    await transaction.save();

    // If withdrawal approved and wasn't already, deduct balance
    if (transaction.type === 'withdrawal' && status === 'completed' && oldStatus === 'pending') {
      await User.findByIdAndUpdate(transaction.userId._id, { $inc: { balance: -transaction.amount } });
    }

    // Notify user about transaction status update
    createNotification(
      transaction.userId._id, 
      `Transaction ${status.charAt(0).toUpperCase() + status.slice(1)}! 💸`, 
      `Your ${transaction.type} request of ${transaction.amount}৳ has been ${status}.`,
      transaction.type === 'withdrawal' ? 'withdrawal' : 'system'
    );

    res.json({ message: 'Transaction updated', transaction });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Support Tickets ──────────────────────────────────────────────────────────
exports.getSupportTickets = async (req, res) => {
  try {
    const { status, page = 1, limit = 15 } = req.query;
    const query = {};
    if (status && status !== 'all') query.status = status;

    const total = await SupportTicket.countDocuments(query);
    const tickets = await SupportTicket.find(query)
      .populate('userId', 'name phoneOrEmail')
      .sort({ createdAt: -1 })
      .skip((Number(page) - 1) * Number(limit))
      .limit(Number(limit));

    res.json({ tickets, total, page: Number(page), pages: Math.ceil(total / Number(limit)) });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getSupportTicket = async (req, res) => {
  try {
    const ticket = await SupportTicket.findById(req.params.id).populate('userId', 'name phoneOrEmail');
    if (!ticket) return res.status(404).json({ message: 'Ticket not found' });
    res.json(ticket);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.replyToTicket = async (req, res) => {
  try {
    const { message, status } = req.body;
    const ticket = await SupportTicket.findById(req.params.id);
    if (!ticket) return res.status(404).json({ message: 'Ticket not found' });

    if (message && message.trim()) {
      ticket.replies.push({ message: message.trim(), isAdmin: true });
    }
    if (status) ticket.status = status;

    await ticket.save();
    await ticket.populate('userId', 'name phoneOrEmail');

    res.json({ message: 'Ticket updated', ticket });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Referrals ────────────────────────────────────────────────────────────────
exports.getReferrals = async (req, res) => {
  try {
    const { page = 1, limit = 15 } = req.query;
    const total = await Referral.countDocuments();
    const referrals = await Referral.find()
      .populate('referrerId', 'name phoneOrEmail')
      .populate('referredUserId', 'name phoneOrEmail')
      .sort({ createdAt: -1 })
      .skip((Number(page) - 1) * Number(limit))
      .limit(Number(limit));

    const totalBonus = await Referral.aggregate([{ $group: { _id: null, total: { $sum: '$bonusAwarded' } } }]);

    res.json({ referrals, total, totalBonus: totalBonus[0]?.total || 0 });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Premium Orders ───────────────────────────────────────────────────────────
exports.getPremiumOrders = async (req, res) => {
  try {
    const { status, page = 1, limit = 15 } = req.query;
    const query = {};
    if (status && status !== 'all') query.status = status;

    const total = await PremiumOrder.countDocuments(query);
    const orders = await PremiumOrder.find(query)
      .populate('userId', 'name phoneOrEmail isPremium premiumExpiry')
      .sort({ createdAt: -1 })
      .skip((Number(page) - 1) * Number(limit))
      .limit(Number(limit));

    res.json({ orders, total, page: Number(page), pages: Math.ceil(total / Number(limit)) });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.updatePremiumOrder = async (req, res) => {
  try {
    const { status, adminNote } = req.body;
    const order = await PremiumOrder.findById(req.params.id).populate('userId');
    if (!order) return res.status(404).json({ message: 'Order not found' });

    order.status = status;
    if (adminNote !== undefined) order.adminNote = adminNote;
    await order.save();

    if (status === 'approved') {
      const settings = await GlobalSetting.findOne({ configKey: 'main_config' });
      const pkg = settings?.premiumIpPackages?.find(p => p.id === order.packageId);
      
      // Calculate days: Extract number from duration string (e.g. "1 Month" or "30 Days")
      let days = 30;
      if (pkg) {
        const durationMatch = pkg.duration.match(/(\d+)/);
        if (durationMatch) {
          const val = parseInt(durationMatch[1]);
          if (pkg.duration.toLowerCase().includes('month')) {
            days = val * 30;
          } else if (pkg.duration.toLowerCase().includes('year')) {
            days = val * 365;
          } else {
            days = val;
          }
        }
        
        // Add extra/free days if present
        if (pkg.freeDays) {
          const freeMatch = pkg.freeDays.match(/(\d+)/);
          if (freeMatch) {
            const freeVal = parseInt(freeMatch[1]);
            if (pkg.freeDays.toLowerCase().includes('month')) {
              days += freeVal * 30;
            } else {
              days += freeVal;
            }
          }
        }
      } else {
        // Fallback to old hardcoded map if package not found in settings
        const packageDays = { 'month-1': 37, 'month-3': 105, 'month-6': 210, 'year-1': 424 };
        days = packageDays[order.packageId] || 30;
      }
      
      let currentExpiry = order.userId.premiumExpiry ? new Date(order.userId.premiumExpiry) : new Date();
      if (currentExpiry < new Date()) {
        currentExpiry = new Date();
      }
      
      const premiumExpiry = new Date(currentExpiry.getTime() + days * 24 * 60 * 60 * 1000);
      
      await User.findByIdAndUpdate(order.userId._id, { 
        isPremium: true, 
        premiumExpiry,
        premiumCountry: order.country || '',
        premiumPackageName: order.packageName || ''
      });

      // Activate referral bonus for the user who purchased VPN (if they were referred)
      activateReferralBonus(order.userId._id);

      // Notify user about approval
      createNotification(
        order.userId._id, 
        'Premium Account Activated! ✨', 
        `Your order for ${order.packageName} has been approved! Your subscription is now active until ${premiumExpiry.toLocaleDateString()}. Added total of ${days} days to your account.`,
        'premium'
      );
    } else if (status === 'rejected') {
      // Notify user about rejection
      createNotification(
        order.userId._id, 
        'Order Rejected ❌', 
        `Your premium order for ${order.packageName} was rejected. Please contact support for details.`,
        'premium'
      );
    }

    const updated = await PremiumOrder.findById(req.params.id).populate('userId', 'name phoneOrEmail isPremium premiumExpiry');
    res.json({ message: 'Order updated', order: updated });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Verifications (Email status only) ───────────────────────────────────────
exports.getVerifications = async (req, res) => {
  try {
    const { status, page = 1, limit = 15 } = req.query;
    const query = {};
    if (status && status !== 'all') query.status = status;

    const total = await Verification.countDocuments(query);
    const verifications = await Verification.find(query)
      .select('-frontImage -backImage -selfieImage')
      .populate('userId', 'name phoneOrEmail')
      .sort({ createdAt: -1 })
      .skip((Number(page) - 1) * Number(limit))
      .limit(Number(limit));

    res.json({ verifications, total });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getVerificationById = async (req, res) => {
  try {
    const verification = await Verification.findById(req.params.id)
      .populate('userId', 'name phoneOrEmail');
    if (!verification) {
      return res.status(404).json({ message: 'Verification request not found' });
    }
    res.json(verification);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.updateVerificationStatus = async (req, res) => {
  try {
    const { status, reviewNote } = req.body;
    if (!['approved', 'rejected'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status' });
    }

    const verification = await Verification.findById(req.params.id);
    if (!verification) {
      return res.status(404).json({ message: 'Verification request not found' });
    }

    verification.status = status;
    if (reviewNote !== undefined) verification.reviewNote = reviewNote;
    await verification.save();

    if (status === 'approved') {
      await User.findByIdAndUpdate(verification.userId, { isEmailVerified: true, verificationBadge: 'blue' });
      createNotification(
        verification.userId,
        'Verified Public Figure',
        'This account authentically represents a recognized public figure and has been verified by Zenivio.',
        'badge'
      );
    } else if (status === 'rejected') {
      await User.findByIdAndUpdate(verification.userId, { isEmailVerified: false, verificationBadge: 'none' });
      createNotification(
        verification.userId,
        'Verification Rejected ❌',
        `Your verification request was rejected. Reason: ${reviewNote || 'Documents were unclear'}`,
        'system'
      );
    }

    res.json({ message: `Verification status updated to ${status}`, verification });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Live Support (ChatSessions) ─────────────────────────────────────────────
exports.getChatSessions = async (req, res) => {
  try {
    const { status, page = 1, limit = 15 } = req.query;
    const query = {};
    if (status && status !== 'all') query.status = status;

    const total = await ChatSession.countDocuments(query);
    const sessions = await ChatSession.find(query)
      .populate('userId', 'name phoneOrEmail')
      .sort({ createdAt: -1 })
      .skip((Number(page) - 1) * Number(limit))
      .limit(Number(limit));

    res.json({ 
      sessions, 
      total, 
      page: Number(page), 
      pages: Math.ceil(total / Number(limit)) 
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getChatSession = async (req, res) => {
  try {
    const session = await ChatSession.findById(req.params.id)
      .populate('userId', 'name phoneOrEmail');
    if (!session) return res.status(404).json({ message: 'Session not found' });
    res.json(session);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Global Settings ─────────────────────────────────────────────────────────
exports.getGlobalSettings = async (req, res) => {
  try {
    let settings = await GlobalSetting.findOne({ configKey: 'main_config' });
    if (!settings) {
      settings = await GlobalSetting.create({ configKey: 'main_config' });
    }
    res.json(settings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.updateGlobalSettings = async (req, res) => {
  try {
    const { 
      premiumIpPrice, 
      premiumIpDuration, 
      bkashNumber, 
      nagadNumber, 
      rocketNumber, 
      premiumIpPackages,
      nativeAdsConfig,
      fortuneWheelConfig,
      promoBanner,
      promoBanners,
      admobConfig,
      referralCampaignTarget,
      referralCampaignReward,
      zinipayApiKey,
      zinipayBaseUrl,
      zinipayEnabled
    } = req.body;
    
    let settings = await GlobalSetting.findOne({ configKey: 'main_config' });
    if (!settings) {
      settings = new GlobalSetting({ configKey: 'main_config' });
    }

    if (premiumIpPrice !== undefined) settings.premiumIpPrice = Number(premiumIpPrice);
    if (premiumIpDuration !== undefined) settings.premiumIpDuration = premiumIpDuration;
    if (bkashNumber !== undefined) settings.bkashNumber = bkashNumber;
    if (nagadNumber !== undefined) settings.nagadNumber = nagadNumber;
    if (rocketNumber !== undefined) settings.rocketNumber = rocketNumber;
    if (premiumIpPackages !== undefined) settings.premiumIpPackages = premiumIpPackages;
    if (nativeAdsConfig !== undefined) settings.nativeAdsConfig = nativeAdsConfig;
    if (fortuneWheelConfig !== undefined) settings.fortuneWheelConfig = fortuneWheelConfig;
    if (promoBanner !== undefined) settings.promoBanner = promoBanner;
    if (promoBanners !== undefined) settings.promoBanners = promoBanners;
    if (admobConfig !== undefined) settings.admobConfig = admobConfig;
    if (referralCampaignTarget !== undefined) settings.referralCampaignTarget = Number(referralCampaignTarget);
    if (referralCampaignReward !== undefined) settings.referralCampaignReward = Number(referralCampaignReward);
    if (zinipayApiKey !== undefined) settings.zinipayApiKey = zinipayApiKey;
    if (zinipayBaseUrl !== undefined) settings.zinipayBaseUrl = zinipayBaseUrl;
    if (zinipayEnabled !== undefined) settings.zinipayEnabled = Boolean(zinipayEnabled);

    await settings.save();
    try {
      const earningController = require('./earningController');
      if (earningController && typeof earningController.invalidateSettingsCache === 'function') {
        earningController.invalidateSettingsCache();
      }
    } catch (cacheErr) {
      console.error('Failed to invalidate settings cache:', cacheErr);
    }
    res.json({ message: 'Settings updated successfully', settings });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ARTICLES MANAGEMENT
exports.getArticles = async (req, res) => {
  try {
    const articles = await Article.find().sort({ createdAt: -1 });
    res.json(articles);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.createArticle = async (req, res) => {
  try {
    const { title, content, coins, readingTime, category } = req.body;
    const article = new Article({ title, content, coins, readingTime, category });
    await article.save();
    res.status(201).json(article);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.updateArticle = async (req, res) => {
  try {
    const article = await Article.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!article) return res.status(404).json({ message: 'Article not found' });
    res.json(article);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.deleteArticle = async (req, res) => {
  try {
    const article = await Article.findByIdAndDelete(req.params.id);
    if (!article) return res.status(404).json({ message: 'Article not found' });
    res.json({ message: 'Article deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Products MANAGEMENT ───────────────────────────────────────────────────────
exports.getProducts = async (req, res) => {
  try {
    const products = await CartProduct.find().sort({ createdAt: -1 });
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.createProduct = async (req, res) => {
  try {
    const { title, description, price, originalPrice, badge, inStock, isActive } = req.body;
    let imageUrl = req.body.image || '';

    if (req.file) {
      imageUrl = req.file.filename;
    }

    const product = new CartProduct({ 
      title, 
      description, 
      price: Number(price), 
      originalPrice: Number(originalPrice), 
      image: imageUrl, 
      badge, 
      inStock: inStock === 'true' || inStock === true, 
      isActive: isActive === 'true' || isActive === true 
    });
    
    await product.save();
    res.status(201).json(product);
  } catch (error) {
    console.error('Create Product Error:', error);
    res.status(400).json({ message: error.message });
  }
};

exports.updateProduct = async (req, res) => {
  try {
    const updateData = { ...req.body };
    
    // Parse numeric and boolean fields from FormData strings
    if (updateData.price !== undefined) updateData.price = Number(updateData.price);
    if (updateData.originalPrice !== undefined) updateData.originalPrice = Number(updateData.originalPrice);
    if (updateData.inStock !== undefined) updateData.inStock = updateData.inStock === 'true' || updateData.inStock === true;
    if (updateData.isActive !== undefined) updateData.isActive = updateData.isActive === 'true' || updateData.isActive === true;

    if (req.file) {
      updateData.image = req.file.filename;
    }

    const product = await CartProduct.findByIdAndUpdate(req.params.id, updateData, { new: true });
    if (!product) return res.status(404).json({ message: 'Product not found' });
    res.json(product);
  } catch (error) {
    console.error('Update Product Error:', error);
    res.status(400).json({ message: error.message });
  }
};

exports.deleteProduct = async (req, res) => {
  try {
    const product = await CartProduct.findByIdAndDelete(req.params.id);
    if (!product) return res.status(404).json({ message: 'Product not found' });
    res.json({ message: 'Product deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Weekly Missions MANAGEMENT ──────────────────────────────────────────────
exports.getWeeklyMissions = async (req, res) => {
  try {
    const missions = await WeeklyMission.find().sort({ createdAt: -1 });
    res.json(missions);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.createWeeklyMission = async (req, res) => {
  try {
    const { title, description, rewardCoins, actionUrl, isActive, missionType, targetCount } = req.body;
    const mission = new WeeklyMission({ 
      title, description, rewardCoins, 
      actionUrl: actionUrl || '', 
      isActive,
      missionType: missionType || 'custom',
      targetCount: targetCount ? Number(targetCount) : 5
    });
    await mission.save();
    res.status(201).json(mission);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.updateWeeklyMission = async (req, res) => {
  try {
    const mission = await WeeklyMission.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!mission) return res.status(404).json({ message: 'Mission not found' });
    res.json(mission);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.deleteWeeklyMission = async (req, res) => {
  try {
    const mission = await WeeklyMission.findByIdAndDelete(req.params.id);
    if (!mission) return res.status(404).json({ message: 'Mission not found' });
    res.json({ message: 'Mission deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Announcements ────────────────────────────────────────────────────────────
exports.sendAnnouncement = async (req, res) => {
  try {
    const { title, message } = req.body;
    if (!title || !message) {
      return res.status(400).json({ message: 'Title and message are required' });
    }

    // Fetch all user IDs
    const users = await User.find({}, '_id').lean();
    if (users.length === 0) {
      return res.status(404).json({ message: 'No users found to send announcement' });
    }

    // Create notifications array
    const notifications = users.map(user => ({
      userId: user._id,
      title,
      message,
      type: 'announcement',
      isRead: false
    }));

    // Bulk insert
    await Notification.insertMany(notifications);

    res.status(201).json({ message: `Announcement sent to ${users.length} users successfully` });
  } catch (error) {
    console.error('Error sending announcement:', error);
    res.status(500).json({ message: 'Failed to send announcement' });
  }
};

// ─── Admin Notifications ─────────────────────────────────────────────────────
exports.getAdminNotifications = async (req, res) => {
  try {
    const notifications = await AdminNotification.find()
      .sort({ createdAt: -1 })
      .limit(50);
    res.json(notifications);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.markAdminNotificationRead = async (req, res) => {
  try {
    const notification = await AdminNotification.findByIdAndUpdate(
      req.params.id,
      { isRead: true },
      { new: true }
    );
    if (!notification) {
      return res.status(404).json({ message: 'Notification not found' });
    }
    res.json(notification);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.markAllAdminNotificationsRead = async (req, res) => {
  try {
    await AdminNotification.updateMany({ isRead: false }, { isRead: true });
    res.json({ message: 'All notifications marked as read' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.deleteAdminNotification = async (req, res) => {
  try {
    const notification = await AdminNotification.findByIdAndDelete(req.params.id);
    if (!notification) {
      return res.status(404).json({ message: 'Notification not found' });
    }
    res.json({ message: 'Notification deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
