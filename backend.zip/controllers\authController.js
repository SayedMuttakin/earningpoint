const User = require('../models/User');
const Transaction = require('../models/Transaction');
const Referral = require('../models/Referral');
const Notification = require('../models/Notification');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { OAuth2Client } = require('google-auth-library');

// Get referrer name
exports.getReferrerName = async (req, res) => {
  try {
    const { code } = req.params;
    if (!code) {
      return res.status(400).json({ message: 'Referral code is required' });
    }
    const referrer = await User.findOne({ referralCode: code.trim().toUpperCase() }).select('name phoneOrEmail');
    if (!referrer) {
      return res.status(404).json({ message: 'Referrer not found' });
    }
    res.json({ name: referrer.name || 'Anonymous User' });
  } catch (error) {
    console.error('Fetch Referrer Error:', error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// Check username availability
exports.checkUsernameAvailability = async (req, res) => {
  try {
    const { username } = req.params;
    if (!username || !username.trim()) {
      return res.status(400).json({ available: false, message: 'Username is required' });
    }
    const cleanUsername = username.trim();
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(cleanUsername)) {
      return res.status(400).json({ available: false, message: 'Invalid username format' });
    }

    const code = cleanUsername.toUpperCase();
    const existing = await User.findOne({
      $or: [
        { username: { $regex: new RegExp(`^${cleanUsername}$`, 'i') } },
        { referralCode: code }
      ]
    });

    if (existing) {
      return res.json({ available: false, message: 'Username is already taken' });
    }

    return res.json({ available: true, message: 'Username is available' });
  } catch (error) {
    console.error('Check Username Error:', error);
    res.status(500).json({ available: false, message: 'Server error checking username' });
  }
};

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const googleClient = new OAuth2Client(GOOGLE_CLIENT_ID);

// Generate JWT tokens
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET || 'fallback_secret', {
    expiresIn: '30d',
  });
};

// Register User
exports.registerUser = async (req, res) => {
  const { name, phoneOrEmail, password, referCode, country, username } = req.body;

  try {
    // Username is required and must be 3-20 alphanumeric/underscore characters
    if (!username || !username.trim()) {
      return res.status(400).json({ message: 'Username is required' });
    }
    const usernameClean = username.trim();
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(usernameClean)) {
      return res.status(400).json({ message: 'Username must be 3-20 characters (letters, numbers, underscore only)' });
    }

    const userExists = await User.findOne({ phoneOrEmail });
    if (userExists) {
      return res.status(400).json({ message: 'User already exists' });
    }

    // Username becomes the referral code (uppercase)
    const referralCode = usernameClean.toUpperCase();
    const usernameExists = await User.findOne({ referralCode });
    if (usernameExists) {
      return res.status(400).json({ message: 'Username is already taken. Please choose another.' });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create User — referralCode = username (uppercase)
    const user = await User.create({
      name,
      phoneOrEmail,
      password: hashedPassword,
      country: country || '',
      referralCode,
      username: usernameClean,
    });

    if (user) {
      // Handle Referral Bonus if referCode provided
      if (referCode) {
        const referrer = await User.findOne({ referralCode: referCode.trim().toUpperCase() });
        
        // Don't allow self-referral (though unlikely with manual entry)
        if (referrer && referrer._id.toString() !== user._id.toString()) {
          // 1. Award bonus to referrer
          referrer.balance = (referrer.balance || 0) + 60;
          await referrer.save();

          // 2. Create Transaction for referrer
          await Transaction.create({
            userId: referrer._id,
            type: 'referral_bonus',
            amount: 60,
            description: `Referral bonus for ${user.name || user.phoneOrEmail}`,
            status: 'completed'
          });

          // 3. Create Referral record
          await Referral.create({
            referrerId: referrer._id,
            referredUserId: user._id,
            bonusAwarded: 60,
            status: 'completed'
          });

          // 4. Create Notification for referrer
          await Notification.create({
            userId: referrer._id,
            title: 'Referral Bonus Received! 🎁',
            message: `Congratulations! You've earned 60 TK bonus for referring ${user.name || 'a new friend'}.`,
            type: 'earning'
          });
        }
      }

      res.status(201).json({
        _id: user._id,
        phoneOrEmail: user.phoneOrEmail,
        name: user.name || '',
        darkMode: user.darkMode || false,
        referralCode: user.referralCode || '',
        token: generateToken(user._id),
      });
    } else {
      res.status(400).json({ message: 'Invalid user data' });
    }
  } catch (error) {
    console.error('Registration Error:', error);
    res.status(500).json({ message: error.message || 'Server Error' });
  }
};

// Login User
exports.loginUser = async (req, res) => {
  const { phoneOrEmail, password } = req.body;

  try {
    const user = await User.findOne({ phoneOrEmail });

    if (user && user.password && (await bcrypt.compare(password, user.password))) {
      res.json({
        _id: user._id,
        phoneOrEmail: user.phoneOrEmail,
        name: user.name || '',
        darkMode: user.darkMode || false,
        referralCode: user.referralCode || '',
        token: generateToken(user._id),
      });
    } else {
      res.status(401).json({ message: 'Invalid credentials' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: error.message || 'Server Error' });
  }
};

// Google OAuth
exports.googleAuth = async (req, res) => {
  const { credential } = req.body;

  if (!credential) {
    return res.status(400).json({ message: 'Missing Google credential' });
  }

  try {
    const validClientIds = [
      process.env.GOOGLE_CLIENT_ID,
      '1028494965258-90o444tljgmd5r6c5si8d8oc2oudnhnl.apps.googleusercontent.com',
      '1028494965258-9ql287u3is47brl9sj5icnf4l104ke7r.apps.googleusercontent.com',
      '69669050668-6sk4ga1t8uui25gpji0ckid2css8okua.apps.googleusercontent.com',
      '456619750771-n3vdqc5stcbm1avbr3biglg0p2gof4uk.apps.googleusercontent.com'
    ].filter(Boolean);

    let payload = null;
    try {
      const ticket = await googleClient.verifyIdToken({
        idToken: credential,
        audience: validClientIds,
      });
      payload = ticket.getPayload();
    } catch (tokenErr) {
      // Fallback decode if strict audience fails
      const decoded = jwt.decode(credential);
      if (decoded && decoded.sub && (decoded.email || decoded.name)) {
        payload = decoded;
      } else {
        throw tokenErr;
      }
    }

    const { sub: googleId, email, name, picture } = payload;

    // Try to find existing user by googleId or by email (if they signed up with email)
    let user = await User.findOne({ googleId });

    if (!user && email) {
      user = await User.findOne({ phoneOrEmail: email });
      if (user) {
        // Link existing account to Google
        user.googleId = googleId;
        user.googleAvatar = picture || '';
        // Only set Google name if user has no name yet
        if (!user.name || user.name.trim() === '') {
          user.name = name || '';
        }
        await user.save();
      }
    }

    if (!user) {
      // Create new user via Google
      const generatedUsername = email ? email.split('@')[0].trim() : 'user';
      // Ensure username doesn't already exist
      let finalUsername = generatedUsername;
      let suffix = 1;
      while (await User.findOne({ username: finalUsername })) {
        finalUsername = generatedUsername + suffix;
        suffix++;
      }

      user = await User.create({
        googleId,
        name: name || '',
        phoneOrEmail: email || null,
        googleAvatar: picture || '',
        username: finalUsername,
      });
    }

    res.json({
      _id: user._id,
      phoneOrEmail: user.phoneOrEmail,
      name: user.name || '',
      darkMode: user.darkMode || false,
      referralCode: user.referralCode || '',
      googleAvatar: user.googleAvatar || '',
      token: generateToken(user._id),
    });
  } catch (error) {
    console.error('Google Auth Error:', error);
    res.status(401).json({ message: 'Invalid Google credential' });
  }
};

// Facebook OAuth
exports.facebookAuth = async (req, res) => {
  const { accessToken } = req.body;

  if (!accessToken) {
    return res.status(400).json({ message: 'Missing Facebook token' });
  }

  try {
    // Verify Facebook access token via Graph API
    const fbResponse = await fetch(`https://graph.facebook.com/me?fields=id,name,email,picture.type(large)&access_token=${accessToken}`);
    const fbData = await fbResponse.json();

    if (fbData.error) {
      console.error('Facebook Graph API Error:', fbData.error);
      return res.status(400).json({ message: 'Invalid Facebook token' });
    }

    const { id: facebookId, name, email, picture } = fbData;
    const fbPictureUrl = picture?.data?.url || '';

    // Try to find existing user by facebookId or by email
    let user = await User.findOne({ facebookId });

    if (!user && email) {
      user = await User.findOne({ phoneOrEmail: email });
      if (user) {
        // Link existing account to Facebook
        user.facebookId = facebookId;
        user.facebookAvatar = fbPictureUrl;
        if (!user.name || user.name.trim() === '') {
          user.name = name || '';
        }
        await user.save();
      }
    }

    if (!user) {
      // Create new user via Facebook
      const generatedUsername = email ? email.split('@')[0].trim() : `fb_${facebookId}`;
      let finalUsername = generatedUsername;
      let suffix = 1;
      while (await User.findOne({ username: finalUsername })) {
        finalUsername = generatedUsername + suffix;
        suffix++;
      }

      user = await User.create({
        facebookId,
        name: name || '',
        phoneOrEmail: email || null,
        facebookAvatar: fbPictureUrl,
        username: finalUsername,
      });
    }

    res.json({
      _id: user._id,
      phoneOrEmail: user.phoneOrEmail,
      name: user.name || '',
      darkMode: user.darkMode || false,
      referralCode: user.referralCode || '',
      facebookAvatar: user.facebookAvatar || '',
      token: generateToken(user._id),
    });
  } catch (error) {
    console.error('Facebook Auth Error:', error);
    res.status(500).json({ message: 'Server Error' });
  }
};
